import pynecone as pc


config = pc.Config(
    app_name="your_amicus",
    db_url="sqlite:///pynecone.db",
    env=pc.Env.DEV,
)
